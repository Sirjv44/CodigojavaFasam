package lista2;

import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {	
	Scanner ler = new Scanner(System.in);
	int A, B, C;
	System.out.println("Digite o numero A: ");
	A = ler.nextInt();
	System.out.println("Digite o numero B: ");
	B = ler.nextInt();
	C = A / B;
	if (A%B == 0) {
     System.out.println("O valor "+A+" e o valor de "+B+" e divisivel, seu resultado final e: "+C);
	}
	else {
	 System.out.println("Os valores declarados nao sao divisiveis.");	
	}
  }
}	
