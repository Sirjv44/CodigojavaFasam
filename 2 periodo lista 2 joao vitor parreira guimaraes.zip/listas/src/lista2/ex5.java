package lista2;

import java.util.Scanner;

public class ex5 {

	public static void main(String[] args) {
	Scanner ler = new Scanner (System.in);
	int numeroid, quant1, quant2, quant3, v1, v2, v3;
	double n1, n2, n3, media, mediaex;
	v1 = 10;
	v2 = 10;
	v3 = 10;
	n1 = 0.0;
	n2 = 0.0;
	n3 = 0.0;
	System.out.println("Informe o numero de identificacao:");
	numeroid = ler.nextInt();
	  System.out.println("Informe a nota 1:");
	  if (n1 <= 0 && n1 <= 10) {
		  n1 = ler.nextDouble();
	  }
	  else {
		  System.out.println("Nota invalida, digite uma nota de 0 a 10:");
		  n1 = ler.nextDouble();
	  }
	  System.out.println("Informe a nota 2:");
	  if (n2 <= 0 && n2 <= 10) {
		  n2 = ler.nextDouble();
	  }
	  else {
		  System.out.println("Nota invalida, digite uma nota de 0 a 10:");
		  n2 = ler.nextDouble();
	  }
	  System.out.println("Informe a nota 3:");
	  if (n3 <= 0 && n3 <= 10) {
		  n3 = ler.nextDouble();
	  }
	  else {
		  System.out.println("Nota invalida, digite uma nota de 0 a 10:");
		  n3 = ler.nextDouble();
	  }
	System.out.println("Informe a quantidade de exercicios da avaliacao 1:");
	quant1 = ler.nextInt();
	System.out.println("Informe a quantidade de exercicios da avaliacao 2:");
	quant2 = ler.nextInt();
	System.out.println("Informe a quantidade de exercicios da avaliacao 3:");
	quant3 = ler.nextInt();
	mediaex = (quant1 + quant2 + quant3) / 3;
	media = (n1 + n2 * 2 + n3 * 3 + mediaex) / 7;
	if (media >= 9.0 && media <= 10.0) {
		System.out.println("O aluno caiu no conceito A e foi aprovado");
		System.out.println("O numero do aluno:"+numeroid);
		System.out.println("Notas"+n1+ +n2+ +n3);
		System.out.println("Media de exercicio: "+mediaex);
		System.out.println("Media geral: "+media);
	}
	else if (media >= 7.5 && media < 9.0) {
		System.out.println("O aluno caiu no conceito B e foi aprovado");
		System.out.println("O numero do aluno:"+numeroid);
		System.out.println("Notas"+n1+ +n2+ +n3);
		System.out.println("Media de exercicio: "+mediaex);
		System.out.println("Media geral: "+media);
	}
	else if (media >= 6.0 && media < 7.5) {
		System.out.println("O aluno caiu no conceito C e foi aprovado");
		System.out.println("O numero do aluno:"+numeroid);
		System.out.println("Notas"+n1+ +n2+ +n3);
		System.out.println("Media de exercicio: "+mediaex);
		System.out.println("Media geral: "+media);
	}
	else if (media >= 4.0 && media < 6.0) {
		System.out.println("O aluno caiu no conceito D e foi reprovado");
		System.out.println("O numero do aluno:"+numeroid);
		System.out.println("Notas"+n1+ +n2+ +n3);
		System.out.println("Media de exercicio: "+mediaex);
		System.out.println("Media geral: "+media);
	}
	else if (media < 4.0) {
		System.out.println("O aluno caiu no conceito E e foi reprovado");
		System.out.println("O numero do aluno:"+numeroid);
		System.out.println("Notas"+n1+ +n2+ +n3);
		System.out.println("Media de exercicio: "+mediaex);
		System.out.println("Media geral: "+media);
	}
	
	}

}
