package lista2;

import java.util.Scanner;

public class ex26 {

	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);
	int [] vetor = new int[10];
	int i;
	i = 0;
	while (i  < 10) {
		System.out.println("Digite o valor da posiçao "+i+":");
		vetor[i] = ler.nextInt();
		while (vetor[i] == i ) {
			System.out.println("Valor ja existe!, Digite um valor diferente:");
			vetor[i] = ler.nextInt();
		}
		i = i + 1;
	}
	do {
		System.out.println("Finalizando....., Agora digite 1 para imprimir o vetor");
		i = ler.nextInt();
		switch(i) {
		case 0:
			System.out.println("Finalizando....");
			break;
		case 1:
			for (i = 0; i < 10; i++) {
				System.out.print(vetor[i]);
			}
		}
		
	}while (i != 0);
	

	}

}
