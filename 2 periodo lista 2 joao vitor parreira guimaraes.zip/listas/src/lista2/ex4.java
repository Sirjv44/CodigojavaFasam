package lista2;

import java.util.Scanner;

public class ex4 {

	public static void main(String[] args) {
	Scanner ler = new Scanner (System.in);
	int matriculafuncionario;
	double quantihoraextra, salariominimo, valorhoraextra, salariohe, horaex, salariobr, inss, impostorenda, salarioliq;
	System.out.println("Informe a matricula do funcionario:");
	matriculafuncionario = ler.nextInt();
	System.out.println("Informe a quantidade de horas extras trabalhadas:");
	quantihoraextra = ler.nextDouble();
	salariominimo = 788.0;
	valorhoraextra = 10.0;
	horaex = 0.0;
	impostorenda = 0.0;
	salariohe = horaex * valorhoraextra;
	salariobr = (3 * salariominimo) + horaex;
	if (salariobr >= 1500.0) {
		inss = salariominimo * (12/100);
	}
	if (salariobr >= 2000.0) {
		impostorenda = salariobr * (20/100);
	}
	salarioliq = salariobr - impostorenda;
	System.out.println("salario liquido e: "+salarioliq);
	System.out.println("salario bruto e: "+salariobr);

	}

}
