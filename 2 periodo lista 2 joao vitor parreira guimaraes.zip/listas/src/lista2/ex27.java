package lista2;

public class ex27 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
