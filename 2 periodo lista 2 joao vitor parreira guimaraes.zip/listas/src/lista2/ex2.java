package lista2;

import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);
	int idade;
	System.out.print("Digite sua idade:");
	idade = ler.nextInt();
	if (idade >= 16 && idade <= 17) {
		System.out.println("O eleitor e facultativo");
	}
	else if (idade >= 18 && idade <= 65) {
		System.out.println("O eleitor e obrigatorio");
	}
	else if (idade > 65) {
		System.out.println("O eleitor e dispensado");
	}

	}

}
