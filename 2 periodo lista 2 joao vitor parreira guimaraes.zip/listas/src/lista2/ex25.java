package lista2;

import java.util.Scanner;
import java.lang.Math;

public class ex25 {

	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);
	int i;
	double [] V1 = new double [10];
	double [] V2 = new double [10];
	double [] Resul = new double [10];
	char [] OP = new char [10];
	i = 0;
	while (i < 10) {
		System.out.println("Digite valores do vetor 1:");
		V1 [i] = ler.nextDouble();
		System.out.println("Digite valores do vetor 2:");
		V2 [i] = ler.nextDouble();
		i = i + 1;
		
	}
	while (i != 0) {
		System.out.println("Digite sinais matematicos:");
		OP [i] = ler.next().charAt(0);
		i = i + 1;
		
	}
	Resul [i] = V1 [i] + OP[i] + V2 [i];
	System.out.println("O resultado das operaçoes e: "+Resul);
	

	}

}
