package lista1;

import java.util.Scanner;

public class ex5 {

	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);
	
	double V, VF, desc, valorfinal;
	String produto;
	System.out.print("Informe o nome do produto:");
	produto = ler.nextLine();
	System.out.print("Informe o valor do produto:");
	V = ler.nextDouble();
	System.out.print("Qual o valor do desconto:");
	desc = ler.nextInt();
	
	desc = desc/100;
	valorfinal = V*desc;
	VF = V - valorfinal;
	
	System.out.print("O valor final do(A) "+produto+" sera de "+VF);

	}

}
