package lista1;

import java.util.Scanner;

public class ex2 {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		int n1, n2, quociente, resto;
		double quocientereal;
		
		System.out.print("Digite o primeiro numero:");
		n1 = ler.nextInt();
		System.out.print("Digite agora o segundo numero:");
		n2 = ler.nextInt();
		quociente = n1 / n2;
		System.out.println("Quociente =" + quociente);
		resto = n1 % n2;
		System.out.println("Resto = "+ resto);
		quocientereal = (double) n1 / n2;
		System.out.println("quociente real =" + quocientereal);


	}

}
