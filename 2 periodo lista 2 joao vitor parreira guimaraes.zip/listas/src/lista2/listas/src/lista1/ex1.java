package lista1;

import java.util.Scanner;

public class ex1 {

	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);
	int Ano;
	String nome1, nome2;
	
	Ano = 2018;
	nome1 = "funalo da Silva";
	nome2 = "Ciclana de Tal";
	
	System.out.print(nome1+" e casado com "+nome2+" ha "+Ano+" Anos.");
	
	}

}
