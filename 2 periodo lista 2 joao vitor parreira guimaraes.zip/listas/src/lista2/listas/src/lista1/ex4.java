package lista1;

import java.util.Scanner;

public class ex4 {

	public static void main(String[] args) {
	Scanner lerC = new Scanner(System.in);
	
	double F, C;
	
	System.out.print("Digite uma temperatura celsius:");
	C = lerC.nextDouble();
	
	F = C*(9.0/5.0) + 32.0;
	
	System.out.print("A temperatura em fahrenheit e " +F);

	}

}
