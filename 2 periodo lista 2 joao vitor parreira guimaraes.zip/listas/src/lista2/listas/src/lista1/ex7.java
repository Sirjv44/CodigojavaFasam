package lista1;

import java.util.Scanner;

public class ex7 {

	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);	
	int An, A1, r, N;	
	System.out.print("Digite o primeiro termo:");
	A1 = ler.nextInt();
	System.out.print("Digite o valor da razao:");
	r = ler.nextInt();
	System.out.print("Entre com o termo a ser verificado:");
	N = ler.nextInt();
	
	An = A1 + (N - 1) * r;
	System .out.print("O valor do termo verificado e: "+An);

	}

}
