package lista2;

import java.util.Scanner;

public class ex13 {

	public static void main(String[] args) {
		int senha, confirmaSenha;

	    Scanner scanner = new Scanner(System.in);

	    System.out.println("Este programa valida se a senha cadastrada está correta."
	        + "\nDigite sua senha: ");
	    senha = scanner.nextInt();

	    System.out.println("Confirme sua senha: ");
	    confirmaSenha = scanner.nextInt();

	    while (senha != confirmaSenha) {
	      System.out.println("Senha incorreta!\nTente novamente:");
	      confirmaSenha = scanner.nextInt();
	    }

	    System.out.println("As senhas estão corretas:\n"
	        + "Senha 1: " + senha + "\nSenha 2: " + confirmaSenha);

	    scanner.close();
	  }

}
