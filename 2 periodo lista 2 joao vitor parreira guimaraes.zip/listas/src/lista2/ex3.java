package lista2;

import java.util.Scanner;

public class ex3 {

	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);
	double valorcompra, valorvenda, valor, lucro;
	System.out.println("Digite o valor do produto:");
	valor = ler.nextDouble();
	if (valor < 10.0) {
		System.out.println("O valor "+valor+" corresponde a um lucro de 70%");
	}
	else if (valor <= 10.0 && valor < 30.0) {
		System.out.println("O valor "+valor+" corresponde a um lucro de 50%");
	}
	else if (valor <= 30.0 && valor < 50.0) {
		System.out.println("O valor "+valor+" corresponde a um lucro de 40%");
	}
	else if (valor >= 50.0) {
		System.out.println("O valor "+valor+" corresponde a um lucro de 30%");
	}

	}

}
