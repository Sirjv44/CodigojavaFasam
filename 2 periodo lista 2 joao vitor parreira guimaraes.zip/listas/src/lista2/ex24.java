package lista2;

import java.util.Scanner;

public class ex24 {

	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);
	int i, opcao;
	double [] numeros = new double [10];
	i = 0;
	while ( i < 10) {
		System.out.println("Digite o valor da posiçao "+i);
		numeros[i] = ler.nextDouble();
		i = i + 1;
	}
	do {
		System.out.println("Finalizando....., Agora digite 1 para imprimir o vetor ou 2 para imprimir o vetor de maneira invertida!");
		opcao = ler.nextInt();
		switch(opcao) {
		case 0:
			System.out.println("Finalizando....");
			break;
		case 1:
			for (i = 0; i < 10; i++) {
				System.out.println(numeros[i]);
			}
			break;
		case 2:
			for (i = 9; i > 0; i--) {
				System.out.println(numeros[i]);
			}
			break;
		default:
			System.out.println("Opçao invalida!");
		}
		
	}while (opcao != 0);
	

	}

}
