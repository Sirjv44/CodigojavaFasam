package lista2;

public class ex23 {

	public static void main(String[] args) {
	

	}

}
