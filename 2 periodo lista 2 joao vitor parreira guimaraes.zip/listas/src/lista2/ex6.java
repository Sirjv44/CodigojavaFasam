package lista2;
import java.util.Scanner;
public class ex6 {

	public static void main(String[] args) {
		Scanner ler = new Scanner (System.in);
		int codigoproduto, codigo;	
		
		System.out.print("Informe o codigo do produto a ser verificado: \n");
		codigoproduto = ler.nextInt();
		
		if (codigoproduto == 1) {
			System.out.print("Classifica��o: Alimento nao pareceviel!\n");
			System.out.print("\nCodigo: "+codigoproduto);
			
		}
		else if  (codigoproduto >=2 && codigoproduto <= 4) {
			System.out.print("Classifica��o: Alimento pareceviel!\n");
			System.out.print("\nCodigo: "+codigoproduto);
		}
		else if  (codigoproduto == 5 && codigoproduto == 6) {
			System.out.print("Classifica��o:: Vestuario!\n");
			System.out.print("\nCodigo: "+codigoproduto);
		}
		else if  (codigoproduto == 7) {
			System.out.print("Classifica��o: Higiene pessoal!\n");
			System.out.print("\nCodigo: "+codigoproduto);
		}
		else if  (codigoproduto >=8 && codigoproduto <= 15) {
			System.out.print("Classifica��o: Limpeza e utensilios domesticos!\n");
			System.out.print("\nCodigo: "+codigoproduto);
		}
		else if (codigoproduto > 16 && codigoproduto == 0) {
			System.out.print("Codigo Invalido insara um numero de 1 a 15!\n\n");
			System.out.printf("Informe o codigo do produto a ser verificado: ");
			codigoproduto = ler.nextInt();
		}
		
		
	}

}
