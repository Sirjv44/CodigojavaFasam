package lista1;

import java.util.Scanner;
import java.lang.Math;

public class ex9 {

	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);
	double Area, Perimetro, Raio, raio;
	System.out.print("Digite o valor do raio:");
	Raio = ler.nextDouble();
	Area = Math.PI * Math.pow(Raio, 2);
	Perimetro = 2 * Math.PI * Raio;
	System.out.print("o calculo do perimetro e da area e: "+Area+ " e "+Perimetro);

	}

}
