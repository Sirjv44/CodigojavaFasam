package lista1;

import java.util.Scanner;

public class ex3 {

	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);
	int idade, DV;
	String name;
	System.out.println("Agora digite seu nome:");
	name = ler.nextLine();
	System.out.print("Digite sua idade:");
	idade = ler.nextInt();
	
	DV = idade * 365;
	System.out.printf(name+" voce tem aproximadamente "+DV+" dias de vida.");

	}

}
