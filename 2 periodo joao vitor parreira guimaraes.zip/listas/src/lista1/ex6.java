package lista1;

import java.util.Scanner;

public class ex6 {

	public static void main(String[] args) {
	Scanner ler = new Scanner(System.in);
	
	double LitroGasolina, tempoGasto, VM, Distancia, Autonomia, tempo, V;
	
	System.out.print("Informe o tempo gasto de sua ultima viagem:");
	tempoGasto = ler.nextDouble();
	System.out.print("Informe a que velocidade media de sua viagem voce estava:");
	VM = ler.nextDouble();
	
	Distancia = tempoGasto * VM;
	
	System.out.print("Qual foi a quantidade de litros de gasolina presente no carro:");
	LitroGasolina = ler.nextDouble();
	
	LitroGasolina = Distancia / 12;
	System.out.println("Distancia foi de "+Distancia);
	System.out.println("velocidade media "+VM);
	System.out.println("Tempo gasto "+tempoGasto);
    System.out.println("Litros usados "+LitroGasolina);
	
	}

}
