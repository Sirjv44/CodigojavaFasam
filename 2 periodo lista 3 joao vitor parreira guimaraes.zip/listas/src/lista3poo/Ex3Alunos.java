package lista3poo;

public class Ex3Alunos {

	 private String matricula;
	    private String nome;
	    private double notaProva;
	    private double notaTrabalho;

	    public void media(double nota1, double nota2) {
	        this.notaProva = nota1;
	        this.notaTrabalho = nota2;

	        double mediaPonderada;
	        mediaPonderada = ((this.notaProva*2.5+this.notaTrabalho*2)/(2+2.5));
	        System.out.println("Média final: "+ mediaPonderada);
	    }
	    public void resultadoFinal() {


	    }
	    public void detalhes() {
	        System.out.println("Nome: "+this.nome);
	        System.out.println("Matricula: "+ this.matricula);
	        System.out.println("Nota da prova: "+ this.notaProva);
	        System.out.println("Nota do trabalho: "+ this.notaTrabalho);

	    }
	    public String getMatricula() {
	        return matricula;
	    }
	    public void setMatricula(String matricula) {
	        this.matricula = matricula;
	    }
	    public String getNome() {
	        return nome;
	    }
	    public void setNome(String nome) {
	        this.nome = nome;
	    }
}
