package lista3poo;

import java.util.Scanner;

public class Ex4Principal {

	public static void main(String[] args) {
    Scanner leia = new Scanner(System.in);
		
		System.out.println("Digita o número: ");
		String number = leia.nextLine();
		
		System.out.println("Digita a descrição do produto: ");
		String desc = leia.nextLine();
		
		System.out.println("Quantidade do produto do pedido:");
		int quant = leia.nextInt();
		
		System.out.println("Valor por um item");
		double valor = leia.nextDouble();
		
		Ex4invoice invoi = new Ex4invoice( quant, valor);
		
		invoi.setNum(number);
		invoi.setDesc(desc);
		
		System.out.println("Número: "+invoi.getNum()+
							"\nDescrição: "+invoi.getDescricao()+
							"\nQuantidade: "+invoi.getQuant()+
							"\nValor: "+invoi.getPreco());
		System.out.println();
		
		System.out.println("O Valor total é "+invoi.GetInvoiceAmount());
	}

}
