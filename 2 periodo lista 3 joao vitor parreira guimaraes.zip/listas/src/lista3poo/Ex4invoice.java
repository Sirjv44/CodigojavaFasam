package lista3poo;

public class Ex4invoice {
     
	String num;
	String desc;
	int quant;
	double preco;
	
	public Ex4invoice (int quantinic, double valor) {
		if (quantinic > 0) {
			quant = quantinic;
		}else {
			quant = 0;
		}	
		if (preco > 0.0) {
			preco = valor;
		}else {
			preco = 0.0;
		}
		
	}
	
	public void setQuant(int quantid){
		quant = quantid;
	}
	
	public void setNum(String numero){
		num = numero;
	}
	public void setDesc(String descricao){
		desc = descricao;
	}
	public void setPreco(Double valor){
		preco = valor;
	}
	
	public int getQuant(){
		return quant;
	}
	public String getNum(){
		return num;
	}
	public String getDescricao(){
		return desc;
	}
	public double getPreco(){
		return preco;
	}
	
    public double GetInvoiceAmount(){
		
		double total = quant * preco;
		
		return total;
	}
}
