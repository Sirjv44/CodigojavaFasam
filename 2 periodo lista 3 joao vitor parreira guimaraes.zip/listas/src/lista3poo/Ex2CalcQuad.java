package lista3poo;

public class Ex2CalcQuad {

	   //• area = lado2
		//• perimetro = 4 x lado 
		
		public void calculo_de_quadrado (double lado) {
	    	 double area , perimetro;
	    	 area = lado * lado ; 
	    	 perimetro = 4 * lado ;
	    	 System.out.println("o valor do perimetro e de "+area);
	    	 System.out.println("o valor do perimetro e de "+perimetro);
	     }

}
