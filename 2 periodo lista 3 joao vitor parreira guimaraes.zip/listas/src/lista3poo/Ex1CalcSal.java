package lista3poo;

public class Ex1CalcSal {

    //$177,12 + 3,87%.
		//$382,33+ 8,675% < 8000
		public void calculaSalario (double salario ) {
			if(salario >= 8000) {
				salario = salario +( (salario * 8.675)/ 100);
			} 
			else {
				salario = salario + ((salario* 3.87)/ 100);
			}
			System.out.println("o valor bruto e de "+salario);
		}
}
