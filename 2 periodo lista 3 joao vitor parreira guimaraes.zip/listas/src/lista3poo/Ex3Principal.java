package lista3poo;

public class Ex3Principal {

	public static void main(String[] args) {
		 Ex3Alunos aluno = new Ex3Alunos();
	        aluno.setNome("Magno");
	        aluno.setMatricula("20194456458");
	        aluno.media(9, 5);
	        aluno.detalhes(); 

	}

}
