package lista3poo;

public class Ex5Estoque {


}
