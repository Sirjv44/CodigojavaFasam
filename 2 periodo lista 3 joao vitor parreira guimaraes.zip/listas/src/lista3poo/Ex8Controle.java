package lista3poo;

import java.util.Scanner;

public class Ex8Controle {

	 Integer volumeMaximo=100, canalMaximo=50;
	    
	    Ex8Televisao t = new Ex8Televisao();

	void aumentarVolume(){
	    Integer volume = t.getVolume();
	    if(volume < volumeMaximo){
	       volume++;
	       t.setVolume(volume);
	    }else{
	        System.out.println("Volume já está no máximo");
	    } 
	}
	    
	    void diminuirVolume(){
	        
	    }
	    
	    void subirCanal(){
	        
	    }
	    
	    void descerCanal(){
	        
	    }
}
