package lista3poo;

import java.util.Scanner;

public class Ex1Funcionario {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		Double salario ;
		Ex1CalcSal CS = new Ex1CalcSal(); 
		System.out.println("informe o salario \n");
        salario = ler.nextDouble();

        CS.calculaSalario(salario);
        ler.close();

	}

}
