package lista3poo;

import java.util.Scanner;

public class Ex2Principal {

	public static void main(String[] args) {
		Scanner ler = new Scanner(System.in);
		Double lado , area ;
		Ex2CalcQuad CQ = new Ex2CalcQuad(); 
		System.out.println("informe o valor \n");
        lado = ler.nextDouble();

        CQ.calculo_de_quadrado(lado);
        ler.close();

	}

}
